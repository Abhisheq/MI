<?php
require_once 'DB.php';
DB::$user = 'root';
DB::$password = '';
DB::$dbName = 'bsi_scanner';
?>