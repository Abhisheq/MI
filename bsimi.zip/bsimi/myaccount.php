<?php
ob_start();
session_start();
include 'connect.php';
if(($_SESSION["userEmail"]=="")&&($_SESSION["userType"]!='1')){
    header("Location:index.php");
    exit();
}


/*############ START HERE FOR CREATE NEW USERS #############*/    
if(isset($_POST['NewUSer'])){
 $username = $_POST['uname'];
 $userid = $_POST['username'];  
 $usertype = $_POST['utype'];
 $userstatus = $_POST['ustatus'];
 $password = $_POST['password'];    
 $password = password_hash($password, PASSWORD_DEFAULT);   
 DB::queryFirstRow("SELECT * FROM users WHERE user_email=%s", $_POST['username']); 
 if(DB::count()>0){
  header("Location:myaccount.php?error=1");    
  exit();  
 }else{
 DB::insert('users', array(
  'user_name' => $username,
  'user_email' => $userid,
  'user_type' => $usertype,
  'login_allowed' => $userstatus,
  'password' => $password     
  ));
  header("Location:myaccount.php");    
  exit();  
  }

}

/*############ START HERE FOR PUDATE USERS #############*/
if(isset($_POST['UpdateUSer'])){
 $username = $_POST['uname'];
 $userid = $_POST['username'];  
 $usertype = $_POST['utype'];
 $userstatus = $_POST['ustatus'];
 DB::queryFirstRow("SELECT * FROM users WHERE user_email=%s", $_POST['username']); 
 if(DB::count()>0){
  header("Location:myaccount.php?error=1");    
  exit();  
 }else{   
 DB::update('users', array(
  'user_name' => $username,
  'user_email' => $userid,
  'user_type' => $usertype,
  'login_allowed' => $userstatus   
  ), "id=%d", $_GET['euid']);
 $result = array(
    "success" => true
  );
  header("Location:myaccount.php");    
  exit();  
 }
}

//Delete rows form the database
if(isset($_GET['del'])){
    $dquery = DB::query("DELETE FROM users WHERE id='".$_GET['uid']."'");
    if($dquery){
        header("Location:myaccount.php");
    }else{
        echo "Error!!";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>BSI Market Intelligence</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
 <!-- http://stackoverflow.com/questions/17627058/php-check-if-timestamp-is-greater-than-24-hours-from-now--> 
 <!-- http://stackoverflow.com/questions/12114329/calculating-days-hours-and-minutes-php-->
 <!-- http://stackoverflow.com/questions/1416697/converting-timestamp-to-time-ago-in-php-e-g-1-day-ago-2-days-ago --> 
 <link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet">
    <style>
        body{font-family: 'Raleway', sans-serif; color: #626567;}        
.sidebar-nav {
    display: block;
    float: left;
    width: 250px;
    list-style: none;
    margin: 0;
    padding: 0;
}

#sidebar_menu li a, .sidebar-nav li a {
    color: #999;
    display: block;
    float: left;
    text-decoration: none;
    width: 250px;
    background: #fff;
    /*border-top: 1px solid #333;
    border-bottom: 1px solid #333;*/
    -webkit-transition: background .5s;
    -moz-transition: background .5s;
    -o-transition: background .5s;
    -ms-transition: background .5s;
    transition: background .5s;
}
.sidebar_name {
    padding-top: 25px;
    color: #fff;
    opacity: .7;
}

.sidebar-nav li {
  line-height: 40px;
  text-indent: 20px;
}

.sidebar-nav li .activ{background: #fff;border-left: 3px solid;border-left-color: #d72d18;color: #d72d18;}        
.sidebar-nav li a {
  color: black;
  display: block;
  text-decoration: none;
}

.sidebar-nav li a:hover {
  color:black;
  background:#f5f5f5;
  text-decoration: none;
  cursor: pointer;
  
}


.sidebar-nav li a:focus {
  text-decoration: none;
}

.sidebar-nav > .sidebar-brand {
  height: 65px;
  line-height: 60px;
  font-size: 18px;
}

.sidebar-nav > .sidebar-brand a {
  color: #666;
}

.sidebar-nav > .sidebar-brand a:hover {
  color: #fff;
  background: none;
}

       
.hed{ margin-top:15px;}
.text-white{color:#fff;text-align:right;}   
.txt{vertical-align:middle!important;}        
.md{margin-top:22px;}
        

    </style>
<!--########## START HERE FOR THE FORWARD EMAIL ##########-->  
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css">
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script type="text/javascript">
$(document).ready(function(){ 
	$(".launch-modal").click(function(){
		$("#myModal").modal({
			backdrop: 'static'
		});
	}); 
});
</script> 
</head>
<body>
   <div class="container-fluid" style="background-color:#d72d18;">
    <div class="col-sm-2">
    <img src="images/logo.png" height="64">
    </div>    
    <div class="col-lg-6 hed">
    <form name="search" method="get" action=""> 
        <input type="hidden" name="msgType" value="<?=$_GET['msgType'];?>">
    <div class="input-group">
      <input type="text" class="form-control" name="q" placeholder="Search for...">
      <span class="input-group-btn">
        <input type="submit" class="btn btn-default" name="Search" value="Go!">
      </span>
    </div><!-- /input-group -->
    </form> 
  </div><!-- /.col-lg-6 --> 
    <div class="col-sm-2 md">
    <div class="text-white"><?php echo $_SESSION["userName"];?></div>
    </div>
    <div class="col-sm-2 md">
    <div class="text-white"><a href="#" style="cursor:pointer;"><img src="images/gear.png" height="28" width="28"></a>
        <a href="logOut.php" style="cursor:pointer;"><img src="images/logout.png" height="28" width="28" style="margin-left:28px;"></a></div>
    </div>   
    </div>
    
    
<div class="container-fluid md">
    <?php if(!empty($_GET['error'])){?>
     <div class="alert alert-danger">
    <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
       Email Address already exist.
     </div>
    <?php }?>
    <!-- Sidebar -->
    <div class="col-sm-3">
        <!-- THIS IS FOR UPDATE USERS -->
        <?php if(!empty($_GET['euid'])){?>
           <div class="modal-content">
               <?php $udata = DB::queryFirstRow("SELECT * FROM users WHERE id=%d", $_GET['euid']);@extract($udata);?>
                <form name="mailsend" method="post" action="">
                <div class="modal-header">
                    <h4 class="modal-title">Update Users</h4>
                </div>
                <div class="modal-body">
                    <p><input type="text" name="uname" value="<?=$user_name;?>" class="form-control" placeholder="Enter Users name" required></p>
                    <p><input type="email" name="username" value="<?=$user_email;?>" class="form-control" placeholder="Enter users id" required></p>
                       <p>
                        <select name="utype" class="form-control" required>
                        <option value="">SELECT USER TYPE</option>
                        <option value="1" <?php if($user_type=='1'){echo "selected";}?>>Dashboard User</option>     
                        <option value="0" <?php if($user_type=='0'){echo "selected";}?> >App User</option>
                        <option value="777" <?php if($user_type=='777'){echo "selected";}?>>Dashboard Admin</option>    
                        </select>
                        </p>
                     <p>
                        <select name="ustatus" class="form-control" required>
                        <option value="">SELECT USER STATUS</option>
                        <option value="1" <?php if($login_allowed=='1'){echo "selected";}?> >ACTIVE</option>
                        <option value="0" <?php if($login_allowed=='0'){echo "selected";}?>>INACTIVE</option>    
                        </select>
                        </p>
                </div>
                <div class="modal-footer">
                    <a href="myaccount.php" class="btn btn-primary">Create New</a> 
                    <input type="submit" name="UpdateUSer" class="btn btn-primary" value="UPDATE">
                </div>
                </form>
            </div>
        <?php }else{?>
        <!-- THIS IS FOR CREATE NEW USERS -->
        <div class="modal-content">
                <form name="mailsend" method="post" action="">
                <div class="modal-header">
                    <h4 class="modal-title">Create New Users</h4>
                </div>
                <div class="modal-body">
                    <p><input type="text" name="uname" class="form-control" placeholder="Enter Users name" required></p>
                    <p><input type="email" name="username" class="form-control" placeholder="Enter users id" required></p>
                    <p><input type="password" name="password" class="form-control" placeholder="Enter users password" required></p>
                       <p>
                        <select name="utype" class="form-control" required>
                        <option value="">SELECT USER TYPE</option>
                        <option value="0">App User</option>
                        <option value="1">Dashboard User</option>    
                        <option value="777">Dashboard Admin</option>    
                        </select>
                        </p>
                     <p>
                        <select name="ustatus" class="form-control" required>
                        <option value="">SELECT USER STATUS</option>
                        <option value="1">ACTIVE</option>
                        <option value="0">INACTIVE</option>    
                        </select>
                        </p>
                </div>
                <div class="modal-footer">
                    <input type="submit" name="NewUSer" class="btn btn-primary" value="SUBMIT">
                </div>
                </form>
            </div>
          <?php } ?>
        
        
        
        
    </div>  
<div class="col-sm-9">    
  <table class="table">
    <tbody>
       <tr class="active">
        <th>USER NAME</th>
        <th>EMAIL</th>
        <th>USER TYPE</th>
        <th>STATUS</th> 
        <th>ACTION</th>   
       </tr>
        <?php
            $row_num = 1;
            $userData = DB::query("SELECT * FROM users ORDER BY id DESC");
            foreach($userData as $urows){ @extract($urows);
            $ractv = (++$row_num % 2) ? 'active' : '';                          
          ?>
        <tr class="<?=$ractv;?>">
        <td class="txt"><?=ucwords($user_name);?></td>
        <td class="txt"><?=$user_email;?></td>
        <td class="txt"><a href="#" class="btn btn-warning btn-xs">
            <?php if($user_type==0){echo "App User";}elseif($user_type==1){echo "Dashboard User";}else{echo "Dashboard Admin";}?></a></td>
        <td class="txt"><a href="#" class="btn btn-info btn-xs"><?php if($login_allowed!=0){echo "ACTIVE";}else{echo "INACTIVE";}?></a></td>
        <td class="txt"><a href="myaccount.php?euid=<?=$id;?>" class="btn btn-success btn-xs">
            <span class="glyphicon glyphicon-edit"></span> Edit</a>
            <a href="myaccount.php?del&uid=<?=$id;?>" class="btn btn-danger btn-xs" onclick="return confirm('Are you sure you want to delete?')">
          <span class="glyphicon glyphicon-trash"></span> Delete
        </a></td>    
      </tr>
      <?php  }?>
        
    </tbody>
  </table>
    </div>
</div>
</body>
</html>
