<?php
ob_start();
session_start();
include 'connect.php';

?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>BSI Market Intelligence</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
 <!-- http://stackoverflow.com/questions/17627058/php-check-if-timestamp-is-greater-than-24-hours-from-now--> 
 <!-- http://stackoverflow.com/questions/12114329/calculating-days-hours-and-minutes-php-->
 <!-- http://stackoverflow.com/questions/1416697/converting-timestamp-to-time-ago-in-php-e-g-1-day-ago-2-days-ago --> 
 <link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet">
    <style>
        body{font-family: 'Raleway', sans-serif; color: #626567;}        
.sidebar-nav {
    display: block;
    float: left;
    width: 250px;
    list-style: none;
    margin: 0;
    padding: 0;
}

#sidebar_menu li a, .sidebar-nav li a {
    color: #999;
    display: block;
    float: left;
    text-decoration: none;
    width: 250px;
    background: #fff;
    /*border-top: 1px solid #333;
    border-bottom: 1px solid #333;*/
    -webkit-transition: background .5s;
    -moz-transition: background .5s;
    -o-transition: background .5s;
    -ms-transition: background .5s;
    transition: background .5s;
}
.sidebar_name {
    padding-top: 25px;
    color: #fff;
    opacity: .7;
}

.sidebar-nav li {
  line-height: 40px;
  text-indent: 20px;
}

.sidebar-nav li .activ{background: #fff;border-left: 3px solid;border-left-color: #d72d18;color: #d72d18;}        
.sidebar-nav li a {
  color: black;
  display: block;
  text-decoration: none;
}

.sidebar-nav li a:hover {
  color:black;
  background:#f5f5f5;
  text-decoration: none;
  cursor: pointer;
  
}


.sidebar-nav li a:focus {
  text-decoration: none;
}

.sidebar-nav > .sidebar-brand {
  height: 65px;
  line-height: 60px;
  font-size: 18px;
}

.sidebar-nav > .sidebar-brand a {
  color: #666;
}

.sidebar-nav > .sidebar-brand a:hover {
  color: #fff;
  background: none;
}

       
.hed{ margin-top:15px;}
.text-white{color:#fff;text-align:right;}   
.txt{vertical-align:middle!important;}        
.md{margin-top:22px;}
        
.table tr{
    cursor: pointer!important;
}      
    </style>
<script>
$(document).ready(function(){
    $('table tr').click(function(){
        window.location = $(this).attr('href');
        return false;
    });
});    
</script>    
</head>
<body>
   <div class="container-fluid" style="background-color:#d72d18;">
    <div class="col-sm-2">
    <img src="images/logo.png" height="64">
    </div>    
    <div class="col-lg-6 hed">
    <div class="input-group">
      <input type="text" class="form-control" placeholder="Search for...">
      <span class="input-group-btn">
        <input type="submit" class="btn btn-default" name="Search" value="Go!">
      </span>
    </div><!-- /input-group -->
  </div><!-- /.col-lg-6 --> 
    <div class="col-sm-2 md">
    <div class="text-white"><?php echo $_SESSION["userName"];?></div>
    </div>
    <div class="col-sm-2 md">
    <div class="text-white"><a href="#" style="cursor:pointer;"><img src="images/gear.png" height="28" width="28"></a>
        <a href="logOut.php" style="cursor:pointer;"><img src="images/logout.png" height="28" width="28" style="margin-left:28px;"></a></div>
    </div>   
    </div>
    
    
<div class="container-fluid md">
    <!-- Sidebar -->
    <div class="col-sm-3">
      <div id="sidebar-wrapper">
        <ul class="sidebar-nav" id="sidebar"> 
        <?php 
          if($_REQUEST['msgType']=="ci"){ $actvClas = "activ";}else{$actvClas = "";}
          if($_REQUEST['msgType']=="mi"){ $actvClas1 = "activ";}else{$actvClas1 = "";}
          if($_REQUEST['msgType']=="gi"){ $actvClas2 = "activ";}else{$actvClas2 = "";}
          if($_REQUEST['msgType']=="ti"){ $actvClas3 = "activ";}else{$actvClas3 = "";}
          if($_REQUEST['msgType']=="trends"){ $actvClas4 = "activ";}else{$actvClas4 = "";}    
         ?>    
          <li><a href="dashboard.php?msgType=ci" class="<?=$actvClas;?>">Competitor Information</a></li>
          <li><a href="dashboard.php?msgType=mi" class="<?=$actvClas1;?>">Market Intelligence</a></li>
          <li><a href="dashboard.php?msgType=gi" class="<?=$actvClas2;?>">Global Intelligence</a></li>
          <li><a href="dashboard.php?msgType=ti" class="<?=$actvClas3;?>">Traning Information</a></li>
          <li><a href="dashboard.php?msgType=trends" class="<?=$actvClas4;?>">Market Trends</a></li>    
        </ul>
      </div>
    </div>
<div class="col-sm-9">    
  <table class="table">
    <tbody>
      <?php 
        
        $userResult = DB::query("SELECT users.id,users.user_name,users.user_email,messages.id,messages.user_id,messages.subject,messages.message,messages.attachments, messages.is_read,messages.forwarded,messages.datetime,messages.msg_type FROM users JOIN messages ON users.id=messages.user_id AND messages.msg_type='".$_REQUEST['msgType']."' ORDER BY messages.id DESC");
        $count = DB::count();
        if($count >0){
        foreach ($userResult as $urow) {  @extract($urow);
        if($is_read==1){ $actv = "active";}else{$actv = "";} 
        //this is for time and date calculation                                    
         $exmtime = explode(" ",$datetime); 
         date_default_timezone_set('Asia/Kolkata');                                
         $timestamp = strtotime($exmtime[0]. ' '.$exmtime[1]); //1373673600
         $cDate = strtotime(date('Y-m-d H:i:s'));
        // Getting the value of old date + 24 hours
         $oldDate = $timestamp + 86400; // 86400 seconds in 24 hrs                               
         if($oldDate < $cDate){
           $dd = date("M d",strtotime($datetime));
            }else{
           $dd = date('H:i a',strtotime($exmtime[1]));
          }
         if($attachments!=0){ $attach = '<span class="glyphicon glyphicon-paperclip"></span>&nbsp;<span class="text-right">('.$attachments.')</span>';}else{$attach ="";}
         ?>
       <tr class="<?=$actv;?>" href="message.php?msgid=<?=$urow['id'];?>&msgType=<?=$urow['msg_type'];?>">
        <td class="txt"><input type="checkbox"></td>
        <td class="txt"><?=ucwords($user_name);?><?=$kk;?></td>
        <td class="txt"><b><?=ucwords($subject);?></b> - <?=stripslashes(substr($message,0,75));?> </td>
        <td class="txt"><?=$attach;?></td>
        <td class="txt"><?=$dd;?></td>
      </tr>
        <?php } }else{?>
       <tr>
        <td colspan="5" class="active" style="text-align:center;">Sorry data not found!</td>
      </tr>     
    <?php } ?>
      
        
    </tbody>
  </table>
    </div>
</div>
</body>
</html>
