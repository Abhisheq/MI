<?php
require 'Mail/PHPMailerAutoload.php';

$mail = new PHPMailer;

//$mail->SMTPDebug = 3;                               // Enable verbose debug output

$mail->isSMTP();                                      // Set mailer to use SMTP
$mail->Host = 'smtp.gmail.com';  // Specify main and backup SMTP servers
$mail->SMTPAuth = true;                               // Enable SMTP authentication
$mail->Username = 'support@weeworks.co.uk';                 // SMTP username
$mail->Password = 'Aberdeen12';                           // SMTP password
$mail->SMTPSecure = 'ssl';                            // Enable TLS encryption, `ssl` also accepted
$mail->Port = 465;                                    // TCP port to connect to

$mail->setFrom($_POST['ford_email'], $_POST['forward_name']);
$mail->addAddress($_POST['forward'], $_POST['forward_name']); 
// $mail->addReplyTo('info@example.com', 'Information');
// $mail->addCC('cc@example.com');
// $mail->addBCC('bcc@example.com');

for($i = 0; $i<=count($_POST['ford_attach']); $i++){
$mail->AddAttachment("uploads/".$_POST['ford_attach'][$i]);
}    
// Add attachments
// $mail->addAttachment('/tmp/image.jpg', 'new.jpg');    // Optional name
$mail->isHTML(true);                                  // Set email format to HTML

$mail->Subject = $_POST['ford_subject'];
$mail->Body    = $_POST['forward_Msg'];
//$mail->AltBody = 'This is the body in p lain text for non-HTML mail clients';

if(!$mail->send()) {
    echo 'Message could not be sent.';
    echo 'Mailer Error: ' . $mail->ErrorInfo;
} else {
    echo 'Message has been sent with attachments';
}
?>