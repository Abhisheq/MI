<?php 

include 'connect.php';
//$fileExt = $_FILES['uploaded_file']['name'];
$fileExt = explode(".",$_FILES['uploaded_file']['name']);
$fileName = time();
$uploadFileName = $fileName.".".$fileExt[1];
$messageId = $_GET["message_id"];
//new script 
$result;
$targetfolder = "./uploads/";
$targetfolder = $targetfolder . $uploadFileName;

if(move_uploaded_file($_FILES['uploaded_file']['tmp_name'], $targetfolder)){
database_1::insert("uploads",array(
  "message_id" => $messageId,
  "file_name" => $uploadFileName
));    
    
 $result = array(
        "success" => true
    );
}else{
 $result = array(
        "success" => false
    );
}
echo json_encode($result);
?>