<?php
include 'connect.php';

$email = $_POST['email']; 
$password = $_POST['password'];
$user_name = $_POST['user_name'];

$password = password_hash($password, PASSWORD_DEFAULT);

$email_end = substr($email, -12, 12);
if($email_end=="bsigroup.com"){
 
DB::queryFirstRow("SELECT * FROM users WHERE user_email=%s",$email);
$validate = DB::count();

if($validate>0){
    $result = array(
        "success" => false,
        "message" => "Email already exist. Please contact IT department."
    );
    
    echo json_encode($result);
    exit();
}

DB::insert('users', array(
    'user_email' => $email,
    'password' => $password,
    'user_name' => $user_name,
    'user_type' => '0',
    'login_allowed' => "1"
));

$result = array(
    "success" => true
);

echo json_encode($result);
exit();

}else{
    $result = array(
        "success" => false,
        "message" => "Please contact IT department."
    );
    echo json_encode($result);
    exit();
}