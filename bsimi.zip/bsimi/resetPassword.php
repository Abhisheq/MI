<?php
include 'connect.php';
$email = $_POST['email'];
$randnum = rand(1111111111,9999999999);
 

$userData = DB::queryFirstRow("SELECT * FROM users WHERE user_email=%s", $email);

if(DB::count() == 0){

	$result = array(
        "success" => false,
        "message" => "This email address not exist!"
    );
    
    echo json_encode($result);
    exit();
}  
 
/*######## START HERE FOR THE SEND MAIL ########*/
require 'Mail/PHPMailerAutoload.php';
$mail = new PHPMailer;
//$mail->SMTPDebug = 3;                               // Enable verbose debug output
$mail->isSMTP();                                      // Set mailer to use SMTP
$mail->Host = 'smtp.gmail.com';  // Specify main and backup SMTP servers
$mail->SMTPAuth = true;                               // Enable SMTP authentication
$mail->Username = 'bsi.marketintelligence@gmail.com';                 // SMTP username
$mail->Password = 'marketintelligence';                           // SMTP password
$mail->SMTPSecure = 'ssl';                            // Enable TLS encryption, `ssl` also accepted
$mail->Port = 465;                                    // TCP port to connect to

$mail->setFrom('bsi.marketintelligence@gmail.com', 'BSI Group');
$mail->addAddress($_POST['email'], $_POST['email']); 

$mail->isHTML(true);                                  // Set email format to HTML

$mail->Subject = "Reset Your Password!";
$mail->Body    = 'Dear, <br/>
  Please click on the link and <a href="http://52.10.128.231/bsimi/resetYourPassword.php?randnum='.$randnum.'">Change Your</a> password.';
//$mail->AltBody = 'This is the body in p lain text for non-HTML mail clients';

if(!$mail->send()) {

	 $result = array(
        "success" => false,
        "message" => "Please try again!!"
    );
    echo json_encode($result);
    exit();

}else{
     date_default_timezone_set("Asia/Kolkata");
   DB::update('users', array(
       'resetpass_datetime' => date('Y-m-d H:i:s'),
       'reset_rand' => $randnum
    ), "user_email=%s", $email);
 
   $result = array(
        "success" => true,
        "message" => "Password reset link sent to email"
    );

    

    echo json_encode($result);
    exit();
} //end here isset

 

?>