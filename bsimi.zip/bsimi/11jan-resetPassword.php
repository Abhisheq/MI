<?php

    $result = array(
        "success" => true,
        "message" => "Password reset link sent to email"
    );
    echo json_encode($result);
    exit();

?>