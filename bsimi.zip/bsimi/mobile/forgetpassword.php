<?php

ob_start();
session_start();
include 'connect.php';

function random_number( $length = 6 ) {
    $chars = "0123456789";
    $generateotp = substr( str_shuffle( $chars ), 0, $length );
    return $generateotp;
}


//----------FORGET PASSWORD----------
if(isset($_POST['forget'])){
	
	$email = $_POST['email'];
	
	$_SESSION["email"] = $email;
	
	$result = DB::queryFirstRow("SELECT * FROM users WHERE user_email=%s", $_POST['email']); 
	
	
	if(DB::count()>0){
		
		$otp = random_number(6);
	
		$to = $result['user_email'];
		
		$subject = "Your One Time Password";
		$mail_message="Your One Time Password is : ".$otp." ";
		
		$headers  = 'MIME-Version: 1.0' . "\r\n";
		$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
		$headers = "From : BSI GROUP";
		ini_set($email,1);
		mail($to,$subject,$mail_message,$headers);
		
		$res1 = DB::queryFirstRow("UPDATE users SET reset_rand = $otp WHERE user_email=%s", $_POST['email']);
		$_SESSION["otp"] = $otp;
		
		header('Location: enterotp.php');
		
		
	}else{
		header("Location:forgetpass.php?usererror=1");    
		exit();  
	}
}
//----------FORGET PASSWORD END----------


?>
