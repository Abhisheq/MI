<?php

ob_start();
session_start();
include 'connect.php';

//----------OTP VALIDATION----------
if(isset($_POST['getotp'])){
	
	$usermail = $_SESSION["email"];
	
	$result = DB::queryFirstRow("SELECT * FROM users WHERE user_email=%s", $usermail);

	$newotp = $result['reset_rand'];
	
	$checkotp = $_POST['otp'];
	
	if($newotp == $checkotp){
		header('Location: newpassword.php');
		
	}else{
		header("Location:enterotp.php?otperror=1");
		exit();
	}
}
//----------OTP VALIDATION END----------

?>