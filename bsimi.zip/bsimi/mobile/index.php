<?php 
ob_start();
?>
<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>BSI Market Intelligence</title>
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
        <meta name="description" content="Organisational Risk Assesment Tool.">
        <link rel="stylesheet" type="text/css" href="js/semantic.min.css">
        <script src="js/semantic.min.js"></script>
        <script src="js/jquery.min.js"></script>
        <script src="js/form.js"></script>
        <script src="js/transition.js"></script>
        
        <style type="text/css">
    body > .grid {
      height: 100%;
    }
    .image {
      margin-top: -100px;
    }
    .column {
      max-width: 450px;
    }
  </style>
  <script>
  $(document)
    .ready(function() {
      console.log(getURLParameter("invalid"));
      if(getURLParameter("invalid") != undefined){
       var div = document.createElement('div');
       div.className = 'row';

        div.innerHTML = ' <div class="ui negative message">\
                      <div class="header">\
                        Invalid Credentials\
                      </div>\
                      <p>The email id and/or the password in invalid. Please try again.\
                    </p></div>';

         document.getElementById('message').appendChild(div);
        }
      
      $('.ui.form')
        .form({
          fields: {
            email: {
              identifier  : 'email',
              rules: [
                {
                  type   : 'empty',
                  prompt : 'Please enter your e-mail'
                },
                {
                  type   : 'email',
                  prompt : 'Please enter a valid e-mail'
                }
              ]
            },
            password: {
              identifier  : 'password',
              rules: [
                {
                  type   : 'empty',
                  prompt : 'Please enter your password'
                },
                {
                  type   : 'length[6]',
                  prompt : 'Your password must be at least 6 characters'
                }
              ]
            }
          }
        })
      ;
    })
  ;
      
      function getURLParameter(name) {
        return decodeURIComponent((new RegExp('[?|&]' + name + '=' + '([^&;]+?)(&|#|;|$)').exec(location.search)||[,""])[1].replace(/\+/g, '%20'))||null;
      }
      
  </script>
        
    </head>
    <body background="images/bcd.jpg">
   <div class="ui middle aligned center aligned grid">  
  <div class="column">
    <h2 class="ui teal image header">
      <img src="images/bsilogo.png" class="image" style="width: 80%;">
    </h2>
    <form class="ui large form" action="loginToolUser.php" method="post">
      <div class="ui stacked segment">
        <div class="field">
          <div class="ui left icon input">
            <i class="user icon"></i>
            <input type="text" name="email" placeholder="Email address">
          </div>
        </div>
        <div class="field">
          <div class="ui left icon input">
            <i class="lock icon"></i>
            <input type="password" name="password" placeholder="Password">
          </div>
        </div>
        
            <input type="submit" name="Login" value="Login" class="ui fluid large red submit button">
		<div style="float: right; padding:5px; color: #de0000;">
			<a href="signup.php"><span style="color:#de0000; font-weight:900"><u>SignUp</u></span></a>
			
		</div>	
            
      </div>

      <div class="ui error message"></div>
        <div class="ui" id="message"/>

    </form>

  </div>
</div>
    </body>
</html>