<?php
ob_start();
session_start();
include 'connect.php';


?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>BSI Market Intelligence</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
 <!-- http://stackoverflow.com/questions/17627058/php-check-if-timestamp-is-greater-than-24-hours-from-now--> 
 <!-- http://stackoverflow.com/questions/12114329/calculating-days-hours-and-minutes-php-->
 <!-- http://stackoverflow.com/questions/1416697/converting-timestamp-to-time-ago-in-php-e-g-1-day-ago-2-days-ago --> 
 <link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet">
 
 
 <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >

<!-- Optional theme -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" >

<link rel="stylesheet" href="forgetformstyle.css" >

<!-- Latest compiled and minified JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

 
 <style>
        body{font-family: 'Raleway', sans-serif; color: #626567;}        
.sidebar-nav {
    display: block;
    float: left;
    width: 250px;
    list-style: none;
    margin: 0;
    padding: 0;
}

#sidebar_menu li a, .sidebar-nav li a {
    color: #999;
    display: block;
    float: left;
    text-decoration: none;
    width: 250px;
    background: #fff;
    /*border-top: 1px solid #333;
    border-bottom: 1px solid #333;*/
    -webkit-transition: background .5s;
    -moz-transition: background .5s;
    -o-transition: background .5s;
    -ms-transition: background .5s;
    transition: background .5s;
}
.sidebar_name {
    padding-top: 25px;
    color: #fff;
    opacity: .7;
}

.sidebar-nav li {
  line-height: 40px;
  text-indent: 20px;
}

.sidebar-nav li .activ{background: #fff;border-left: 3px solid;border-left-color: #d72d18;color: #d72d18;}        
.sidebar-nav li a {
  color: black;
  display: block;
  text-decoration: none;
}

.sidebar-nav li a:hover {
  color:black;
  background:#f5f5f5;
  text-decoration: none;
  cursor: pointer;
  
}


.sidebar-nav li a:focus {
  text-decoration: none;
}

.sidebar-nav > .sidebar-brand {
  height: 65px;
  line-height: 60px;
  font-size: 18px;
}

.sidebar-nav > .sidebar-brand a {
  color: #666;
}

.sidebar-nav > .sidebar-brand a:hover {
  color: #fff;
  background: none;
}

       
.hed{ margin-top:15px;}
.text-white{color:#fff;text-align:right;}   
.txt{vertical-align:middle!important;}        
.md{margin-top:40px;}

	  
</style>

</head>

<body background="images/bcd.jpg"> 

<div class="container-fluid" style="background-color:#d72d18;">
    <div class="col-sm-2">
    <img src="images/logo.png" height="64">
    </div>
</div>

<div class="container-fluid md"> 


		<?php if(!empty($_GET['usererror'])){?>
			<div class="alert alert-danger">
				<a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
				User name does not exist in database
			</div>
		<?php }?>
		<?php if(!empty($_GET['emailfailed'])){?>
			<div class="alert alert-danger">
				<a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
				Failed to Recover your password, Try Again
			</div>
		<?php }?>
   
		<!-- FORGET PASSWORD -->
        <form class="form-signin" method="POST" action="forgetpassword.php">
        <h2 class="form-signin-heading">Forgot Password</h2>
        <div class="input-group">
	  <span class="input-group-addon" id="basic-addon1">@</span>
	  <input type="email" name="email" class="form-control" placeholder="Username@bsigroup.com" required>
	</div>
	<br />
	
		<div class="modal-footer">
			<input type="submit" name="forget" class="btn btn-lg btn-primary btn-block" value="SUBMIT">
        </div>
		
		
      </form>
</div>


</body>
</html>