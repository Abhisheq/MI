<?php
                require 'database.php';
				session_start();
				$sql= $_SESSION['id'];
				
                
                    $query = "SELECT * FROM messages WHERE msg_type='trends' AND user_id='$sql' ORDER BY id DESC";
					
                    $query_run = mysqli_query($con,$query);
					
                    while($query_row = mysqli_fetch_assoc($query_run)):?>

<div style="text-align: right; padding:0 10px 0px 0"> <?php echo $query_row['subject'].' '; ?> </div>
<span style=" background-color: #ddd; float:right; padding:9px; margin-right:10px; border-radius:4px;"> <?php echo $query_row['message'].' '; ?> </span>
<br /><br /><br />


<?php
//date_default_timezone_set('Asia/Kolkata');
//echo date("m/d/Y - H:i:s A", time());
?> <!-- IST -->

<!-- <div id ="chat_data" style="text-align: center;">
			   <?php echo formatDate($query_row['date']); ?>
                </div>	--> 
<!--<span style = "font-family:cursive;float:right; color:#aaaaaa; font-size: 12px; margin-left: 10px; border: #000000; margin-top:4px;">
			<?php echo formatDate($query_row['date']); ?></span>-->

<?php endwhile; ?>
