<?php
session_start();
include 'database.php';
$subject = $_POST['subject'];
$message  = $_POST['message'];

//echo $_POST['password']; die();
$msgData = DB::queryFirstRow("SELECT * FROM messages WHERE subject=$subject AND message=$message");

	
$_SESSION["is_valid"] = true;

$_SESSION["msgid"] = $msgData['id'];

header("Location:competitor.php");
exit();
