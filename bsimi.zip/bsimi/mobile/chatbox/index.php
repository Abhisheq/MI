<?php
    include 'database.php';
	session_start();
	$userid = $_SESSION['id'];

	if(!isset($_SESSION['id']))
	{
		// not logged in
		header('location:../index.php');
		exit();
	}
	
?>

<!DOCTYPE html>
<html>

<!-- Head -->
<head>
<title>BSI MI TOOL</title>
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta name="keywords" content="BSI Marketing Intelligence Tool" />
<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<link rel="stylesheet" href="css/style.css" type="text/css" media="all">
<link rel="stylesheet" href="competitor_style.css">
<link href='//fonts.googleapis.com/css?family=Raleway:400,500,600,700,800' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Open+Sans:400,600,700' rel='stylesheet' type='text/css'>
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
</head>
<!-- //Head -->

<!-- Body -->
<body>
<div class="row">
  <div class="container">
    <nav class="navbar avbar-default navbar-fixed-top text-center">
      <div class="col-lg-10 col-md-10 col-sm-10 col-xs-10 well">
        <div class="blacktext"> Report Category </div>
      </div>
      <div class="col-lg-2 col-md-2 col-sm-2 col-xs-2 well">
        <a href="logOut.php" style="cursor:pointer;"><i class="glyphicon glyphicon-log-out logoutglyph"></i> </a>
      </div>
    </nav>
  </div>
</div>
<div class="row">
  <div id="chatbox">
    <div id="friends" style="margin-top:90px;">
      <div class="friend w3layouts"> <a href="competitor.php">
        <p> <strong>Competitor Information</strong> </p>
        </a> </div>
      <div class="friend"> <a href="market.php">
        <p> <strong>Market Intelligence</strong> </p>
        </a> </div>
      <div class="friend"> <a href="global.php">
        <p> <strong>Global Intelligence</strong> </p>
        </a> </div>
      <div class="friend"> <a href="training.php">
        <p> <strong>Training Information</strong> </p>
        </a> </div>
      <div class="friend agileits"> <a href="trends.php">
        <p> <strong>Market Trends</strong> </p>
        </a> </div>
    </div>
  </div>
</div>

<!-- Custom-JavaScript-File-Links --> 
<!-- Default-JavaScript --> <script src="js/jquery.min.js"></script> 
<!-- Tabs-JavaScript --> 
<!-- //Custom-JavaScript-File-Links -->

</body>
<!-- //Body -->

</html>