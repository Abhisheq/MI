<?php
                require 'database.php';
				session_start();
				$sql= $_SESSION['id'];
				
                
                    $query = "SELECT * FROM messages WHERE msg_type='ci' AND user_id='$sql' ORDER BY id ASC";
					
                    $query_run = mysqli_query($con,$query);
					
                    while($query_row = mysqli_fetch_assoc($query_run)):?>


	<span style=" background-color: #ddd; float:right; padding:9px; margin:0px 10px 15px 0px; clear: both; border-radius:4px;">
		<div style="padding:0 10px 10px 0; text-decoration: underline; font-size:18px;">
			<?php echo $query_row['subject'].' '; ?>
		</div> 
		<?php echo $query_row['message'].' '; ?> 
		<span style = "font-family:cursive; text-align:right; color:#aaaaaa; font-size: 12px; margin-left: 10px; border: #000000;">
			<?php echo formatDate($query_row['datetime']); ?>
		</span>
	</span>
	
<br /><br /><br /><br><br>
	


<?php
//date_default_timezone_set('Asia/Kolkata');
//echo date("m/d/Y - H:i:s A", time());
?> <!-- IST -->

<!-- <div id ="chat_data" style="text-align: right;">
			   <?php echo formatDate($query_row['datetime']); ?>
                </div>		-->


<?php endwhile; ?>
