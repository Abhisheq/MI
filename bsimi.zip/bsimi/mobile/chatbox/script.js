  function ajax1()
    {
//        var request = new XMLHttpRequest();
//        request.onreadystatechange = function()
//        {
//            if(request.readyState == 4 && request.status == 200)
//            {
//                document.getElementById('chat').innerHTML = request.responseText;
//
//            }
//
//        }
//
//        request.open('GET','chat1.php',true);
//        request.send();
        
    $.ajax({url: "chat1.php", success: function(result)
        {
            $("#chat1").html(result);
    
        }});

    }
	
	function ajax2()
    {
//        var request = new XMLHttpRequest();
//        request.onreadystatechange = function()
//        {
//            if(request.readyState == 4 && request.status == 200)
//            {
//                document.getElementById('chat').innerHTML = request.responseText;
//
//            }
//
//        }
//
//        request.open('GET','chat1.php',true);
//        request.send();
        
    $.ajax({url: "chat2.php", success: function(result)
        {
            $("#chat2").html(result);
    
        }});

    }
	
	function ajax3()
    {
//        var request = new XMLHttpRequest();
//        request.onreadystatechange = function()
//        {
//            if(request.readyState == 4 && request.status == 200)
//            {
//                document.getElementById('chat').innerHTML = request.responseText;
//
//            }
//
//        }
//
//        request.open('GET','chat1.php',true);
//        request.send();
        
    $.ajax({url: "chat3.php", success: function(result)
        {
            $("#chat3").html(result);
    
        }});

    }
	
	function ajax4()
    {
//        var request = new XMLHttpRequest();
//        request.onreadystatechange = function()
//        {
//            if(request.readyState == 4 && request.status == 200)
//            {
//                document.getElementById('chat').innerHTML = request.responseText;
//
//            }
//
//        }
//
//        request.open('GET','chat1.php',true);
//        request.send();
        
    $.ajax({url: "chat4.php", success: function(result)
        {
            $("#chat4").html(result);
    
        }});

    }
	
	function ajax5()
    {
//        var request = new XMLHttpRequest();
//        request.onreadystatechange = function()
//        {
//            if(request.readyState == 4 && request.status == 200)
//            {
//                document.getElementById('chat').innerHTML = request.responseText;
//
//            }
//
//        }
//
//        request.open('GET','chat1.php',true);
//        request.send();
        
    $.ajax({url: "chat5.php", success: function(result)
        {
            $("#chat5").html(result);
    
        }});

    }
	
    
    setInterval(function(){ajax();},1000);

            