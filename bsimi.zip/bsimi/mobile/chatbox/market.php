<?php
    include 'database.php';
	session_start();
	$userid = $_SESSION['id'];
?>

<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<link rel="stylesheet" href="competitor_style.css">
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
</head>

<body onload= "ajax2();">

<!-- TOP MAIN HEADER STARTS -->
<div class="row">
  <div class="container">
    <nav class="navbar navbar-default navbar-fixed-top">
      <div class="topheader">
        <h4> Market Intelligence </h4>
      </div>
    </nav>
  </div>
</div>
<!-- TOP MAIN HEADER ENDS --> 

<!-- MIDDLE CHAT BODY SECTION STARTS -->
<div class="row middlechatarea">
  <div id="chat2"> </div>
</div>
<!-- MIDDLE CHAT BODY SECTION ENDS --> 

<!-- FOOTER STARTS -->
<div class="row">
  <div class="container">
    <div class="footer">
      <form method="post" action="market.php" class="form-horizontal" enctype="multipart/form-data" accept-charset='UTF-8'>
        <!--<label for='photo' >Upload your photo:</label><br/>-->
        <input type="file" name='image' id='photo' />
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
          <input type="text" multiple class="form-control myinptbx" id="" placeholder="Enter Your Subject" name ="subject" required>
          <textarea name = "message" class="form-control" rows="1" placeholder="Enter Your Message...." id="comment" required></textarea>
        </div>
        <!--<div class="col-lg-3 col-md-3 col-sm-3 col-xs-3">
          <button type="reset" name = "reset" value="Reset" class="btn btn-primary">Reset</button>
        </div>-->
        <div class="col-lg-2 col-md-2 col-sm-2 col-xs-2">
          <button type="submit" name = "submit" value="Click Me!" class="btn btn-success mybtn"> Send </button>
        </div>
      </form>
    </div>
  </div>
</div>
<!-- FOOTER ENDS -->

<?php
                    if(isset($_POST['subject']) && isset($_POST['message']))
                    {
                        $subject = $_POST['subject'];
//                        echo $subject;
                        $message = $_POST['message'];
//                        echo $message;

						$total = count($_FILES['image']['name']);

                        $query_1 = "INSERT INTO messages (user_id, subject, message, attachments, msg_type) VALUES ('$userid','$subject','$message','$total', 'mi')";
                        
						$query_run = mysqli_query($con,$query_1);
                        if($query_run)
                        {
                            echo "<audio src = 'sound/134332-facebook-chat-sound.mp3' hidden = 'true' autoplay = 'true' /></audio>";
                        }
                   }
            ?>
<?php
		if(isset($_FILES['image'])){
				$errors= array();
				$file_name = time();
				$file_size =$_FILES['image']['size'];
				$file_tmp =$_FILES['image']['tmp_name'];
				$file_type=$_FILES['image']['type'];      
				$file_ext=explode(".",$_FILES['image']['name']);
				
				$uploadname=$file_name.".".$file_ext[1];
	  
				$expensions= array("jpeg","jpg","png");
				
                $image = $_FILES['image'];

				$sql = "SELECT id FROM messages WHERE id = (SELECT MAX(id) FROM messages)";
				$result = $con->query($sql);
				
				if ($result->num_rows > 0) {
				// output data of each row
				while($row = $result->fetch_assoc()) {
							
				ob_start(); //Start output buffer
				echo $row["id"];
				$output = ob_get_contents(); //Grab output
				ob_end_clean(); //Discard output buffer
							
				$query_1 = "INSERT INTO uploads (message_id, file_name) VALUES ('$output','$uploadname')";
							
				$query_run = mysqli_query($con,$query_1);
							
				}
				} else {
					echo "0 results";
				}
				
				$target_dir = "uploads/";
				$target_file = $target_dir . basename($_FILES["image"]["name"]);
				$uploadOk = 1;
				$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
				
				
				// Rename Uploaded File
				// Your file name you are uploading 
				$file_name_main = $_FILES['image']['name'];

				//combine random digit to you file name to create new file name
				//use dot (.) to combile these two variables

				$new_file_name=$uploadname;

				//set where you want to store files
				//in this example we keep file in folder upload 
				//$new_file_name = new upload file name
				//for example upload file name cartoon.gif . $path will be upload/cartoon.gif
				$path= "uploads/".$new_file_name;
				if($image != 'none')
				{
				if(copy($_FILES['image']['tmp_name'], $path))
				{
				echo "Image Successfully Uploaded and Sent<BR/>"; 

				//$new_file_name = new file name
				//echo "File Name :".$new_file_name."<BR/>"; 
				}
				else
				{
				//echo "Error";
				}
				}

				// Check file size
				if($file_size > 15000000){
					$errors[]='File size must be under 15 MB';
				}
				
				// Allow certain file formats
				if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
				&& $imageFileType != "gif" ) {
				//echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
				$uploadOk = 0;
				}
				
		}
?>
</body>
<script src="script.js"></script>
</html>