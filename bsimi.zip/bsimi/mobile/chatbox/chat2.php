<?php
	require 'database.php';
	session_start();
	$sql= $_SESSION['id'];
	$query = "SELECT * FROM messages WHERE msg_type='mi' AND user_id='$sql' ORDER BY id DESC";
	$query_run = mysqli_query($con,$query);
	while($query_row = mysqli_fetch_assoc($query_run)):
?>

<div class="chat_main_box">
  <div class="chat_date_time_box">
    <?php
		//	date_default_timezone_set('Asia/Kolkata');
		//	echo date("l, jS F, Y", time());
		$date = $query_row['datetime'];
		$newDate = date("l, jS F, Y", strtotime($date));
		echo $newDate;
	?>
  </div>
  <div class="chat_area_right">
    <div class="chat_subject"> <?php echo $query_row['subject'].' '; ?> </div>
    <div class="chat_message"> <?php echo $query_row['message'].' '; ?> </div>
    <div class="chat_time"> <?php echo formatDate($query_row['datetime']); ?> </div>
  </div>
</div>

<!-- IST --> 
<!--  <div id ="chat_data" style="text-align: right;">
//<?php echo formatDate($query_row['datetime']); ?>
 </div>  -->
<?php endwhile; ?>