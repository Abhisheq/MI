<?php
session_start();
include 'connect.php';
$email = $_POST['email'];
$password  = $_POST['password'];


//echo $_POST['password']; die();
$userData = DB::queryFirstRow("SELECT * FROM users WHERE user_email=%s AND (user_type=0) AND login_allowed=1", $email);

if(DB::count() == 0){
	header("Location:index.php?invalid=1");
	exit();
}

if(!password_verify($password,$userData['password'])){
	header("Location:index.php?invalid=1");
	exit();
}
	
	
$_SESSION["is_valid"] = true;
$_SESSION["userEmail"] = $email;
$_SESSION["userName"] = $userData['user_name'];
$_SESSION["userType"] = $userData['user_type'];
$_SESSION['id']= $userData['id'];


header("Location:chatbox/index.php");
exit();
