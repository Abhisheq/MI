<?php
ob_start();
session_start();
include 'connect.php';


/*############ START HERE FOR CREATE NEW USERS #############*/    
if(isset($_POST['resetpass'])){
	
	$resetmail = $_SESSION["email"];
	echo "Reset Mail : ".$resetmail."<br>";
	
	$password = $_POST['password'];
	echo "Entered Password : ".$password."<br>";
	
	$hashpass = password_hash($password, PASSWORD_DEFAULT);
	echo "Hashed Password : ".$hashpass."<br>";
 
	$result = DB::queryFirstRow("SELECT * FROM users WHERE user_email=%s", $resetmail); 
	
	$getpass = $result['password'];
	echo "Existing Password : ".$getpass."<br>";
 
	if(DB::count()>0){
		$res1 = DB::queryFirstRow("UPDATE users SET password = '$hashpass' WHERE user_email=%s", $resetmail);
		header("Location:newpassword.php?success=1");    
		exit(); 
	}
	else{
		header("Location:newpassword.php?error=1");
		exit();
	}
}
?>