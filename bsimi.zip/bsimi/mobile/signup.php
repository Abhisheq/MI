<?php
ob_start();
session_start();
include 'connect.php';


/*############ START HERE FOR CREATE NEW USERS #############*/    
if(isset($_POST['NewUSer'])){
 $username = $_POST['uname'];
 $userid = $_POST['username'];  
 
 $_SESSION["username"] = $userid;
 
 $usertype = "0";
 $userstatus = "0";
 $password = $_POST['password'];    
 $password = password_hash($password, PASSWORD_DEFAULT);   
 DB::queryFirstRow("SELECT * FROM users WHERE user_email=%s AND login_allowed=1", $_POST['username']); 
 if(DB::count()>0){
  header("Location:signup.php?error=1");    
  exit();  
 }else {
 DB::insert('users', array(
  'user_name' => $username,
  'user_email' => $userid,
  'user_type' => $usertype,
  'login_allowed' => $userstatus,
  'password' => $password     
  ));
  header("Location:registeruser.php");    
  exit();  
  }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>BSI Market Intelligence</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  
 <link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet">

 
 <style>
        body{font-family: 'Raleway', sans-serif; color: #626567;}        
.sidebar-nav {
    display: block;
    float: left;
    width: 250px;
    list-style: none;
    margin: 0;
    padding: 0;
}

#sidebar_menu li a, .sidebar-nav li a {
    color: #999;
    display: block;
    float: left;
    text-decoration: none;
    width: 250px;
    background: #fff;
    /*border-top: 1px solid #333;
    border-bottom: 1px solid #333;*/
    -webkit-transition: background .5s;
    -moz-transition: background .5s;
    -o-transition: background .5s;
    -ms-transition: background .5s;
    transition: background .5s;
}
.sidebar_name {
    padding-top: 25px;
    color: #fff;
    opacity: .7;
}

.sidebar-nav li {
  line-height: 40px;
  text-indent: 20px;
}

.sidebar-nav li .activ{background: #fff;border-left: 3px solid;border-left-color: #d72d18;color: #d72d18;}        
.sidebar-nav li a {
  color: black;
  display: block;
  text-decoration: none;
}

.sidebar-nav li a:hover {
  color:black;
  background:#f5f5f5;
  text-decoration: none;
  cursor: pointer;
  
}


.sidebar-nav li a:focus {
  text-decoration: none;
}

.sidebar-nav > .sidebar-brand {
  height: 65px;
  line-height: 60px;
  font-size: 18px;
}

.sidebar-nav > .sidebar-brand a {
  color: #666;
}

.sidebar-nav > .sidebar-brand a:hover {
  color: #fff;
  background: none;
}

       
.hed{ margin-top:15px;}
.text-white{color:#fff;text-align:right;}   
.txt{vertical-align:middle!important;}        
.md{margin-top:40px;}
        
</style>

</head>

<body background="images/bcd.jpg"> 

<div class="container-fluid" style="background-color:#d72d18;">
    <div class="col-sm-2">
    <img src="images/logo.png" height="64">
    </div>
</div>

<div class="container-fluid md">
    <?php if(!empty($_GET['error'])){?>
     <div class="alert alert-danger">
    <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
       Email Address already exist.
     </div>
    <?php }?>
	<?php if(!empty($_GET['usererror'])){?>
     <div class="alert alert-danger">
    <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
       Can not send OTP at this time, Please try again later.
     </div>
    <?php }?>
    <!-- Sidebar -->
        <!-- THIS IS FOR CREATE NEW USERS -->
        <div class="modal-content">
                <form name="mailsend" method="post" action="">
                <div class="modal-header">
                    <h4 class="modal-title">Create New Users</h4>
                </div>
                <div class="modal-body">
                    <p><input type="text" name="uname" class="form-control" placeholder="Enter Name" required></p>
                    <p><input type="email" name="username" class="form-control" placeholder="Username@bsigroup.com" pattern=".+@bsigroup.com" required></p>
                    <p><input type="password" name="password" id="password" class="form-control" placeholder="Enter Password" required></p>
					<p><input type="password" name="confirm_password" id="confirm_password" class="form-control" placeholder="Confirm Password" required ></p>
                     
                </div>
				
				<script type="text/javascript">
					function Validate() {
						var password = document.getElementById("password").value;
						var confirmPassword = document.getElementById("confirm_password").value;
						if (password != confirmPassword) {
							alert("Passwords do not match.");
							return false;
						}
						return true;
					}
				</script>
				
                <div class="modal-footer">
                    <input type="submit" name="NewUSer" class="btn btn-primary" value="SIGNUP" onclick="return Validate()">
                </div>
                </form>
            </div>
</div>
</body>
</html>