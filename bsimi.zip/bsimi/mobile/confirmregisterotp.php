<?php

ob_start();
session_start();
include 'connect.php';

//----------OTP VALIDATION----------
if(isset($_POST['getregisterotp'])){
	
	$usermail = $_SESSION["username"];
	
	$result = DB::queryFirstRow("SELECT * FROM users WHERE user_email=%s", $usermail);
	
	$newotp = $result['reset_rand'];
	echo "OTP from database:  ".$newotp."<br>";
	
	$checkotp = $_POST['otp'];
	echo "Entered OTP:  ".$checkotp."<br>";
	
	if($newotp == $checkotp){
		
		$result = DB::queryFirstRow("UPDATE users SET login_allowed = 1 WHERE user_email=%s", $usermail);
		header('Location: registerotp.php?success=1?checkmail=0');
		//header('Location: registerotp.php?checkmail=0');
		exit();
		
	}else{
		header("Location:registerotp.php?otperror=1");
		exit();
	}
}
//----------OTP VALIDATION END----------

?>