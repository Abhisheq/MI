<?php 
ob_start();
session_start();
include 'connect.php';
if(empty($_SESSION["userEmail"])){
    header("Location:index.php");
    exit();
}
/*######### msg read update query #######*/
 DB::update('messages', array(
  'is_read' => '1'
  ), "id=%d", $_GET['msgid']);

/*#######End here ########*/

$msgData = DB::queryFirstRow("SELECT * FROM messages WHERE id=%d",$_GET['msgid']); @extract($msgData);
$userData = DB::queryFirstRow("SELECT * FROM users WHERE id=%d",$msgData['user_id']);

            $dt = new DateTime($datetime);
            $tz = new DateTimeZone('Asia/Kolkata');
            $dt->setTimezone($tz);
            //$dt->format('Y-m-d H:i:s');
/*##### this is for date and time ###*/
         $exmtime = explode(" ",$dt->format('Y-m-d H:i:s')); 
         $timestamp = strtotime($exmtime[0]. ' '.$exmtime[1]); //1373673600
         $cDate = strtotime(date('Y-m-d g:i:s'));
        // Getting the value of old date + 24 hours
         $oldDate = $timestamp + 86400; // 86400 seconds in 24 hrs                               
         if($oldDate < $cDate){
           $dd = date("M d",strtotime($datetime));
            }else{
           $dd = date('g:i A',strtotime($exmtime[1]));
          }
/*######## this is for time and date ago #########*/
 $time_elapsed = timeAgo($time_ago); //The argument $time_ago is in timestamp (Y-m-d H:i:s)format.
   //Function definition
function timeAgo($time_ago)
{
    $time_ago = strtotime($time_ago);
    $cur_time   = time();
    $time_elapsed   = $cur_time - $time_ago;
    $seconds    = $time_elapsed ;
    $minutes    = round($time_elapsed / 60 );
    $hours      = round($time_elapsed / 3600);
    $days       = round($time_elapsed / 86400 );
    $weeks      = round($time_elapsed / 604800);
    $months     = round($time_elapsed / 2600640 );
    $years      = round($time_elapsed / 31207680 );
    // Seconds
    if($seconds <= 60){
        return "just now";
    }
    //Minutes
    else if($minutes <=60){
        if($minutes==1){
            return "one minute ago";
        }else{
            return "$minutes minutes ago";
        }
    }
    //Hours
    else if($hours <=24){
        if($hours==1){
            return "an hour ago";
        }else{
            return "$hours hrs ago";
        }
    }
    //Days
    else if($days <= 7){
        if($days==1){
            return "yesterday";
        }else{
            return "$days days ago";
        }
    }
    //Weeks
    else if($weeks <= 4.3){
        if($weeks==1){
            return "a week ago";
        }else{
            return "$weeks weeks ago";
        }
    }
    //Months
    else if($months <=12){
        if($months==1){
            return "a month ago";
        }else{
            return "$months months ago";
        }
    }
    //Years
    else{
        if($years==1){
            return "one year ago";
        }else{
            return "$years years ago";
        }
    }
}
//Delete rows form the database
if(isset($_GET['del'])){
    $dquery = DB::query("DELETE FROM messages WHERE id='".$_GET['msgid']."'");
    if($dquery){
        $upFl = DB::query("SELECT * FROM uploads WHERE message_id='".$_GET['msgid']."'");
        if(DB::count()>0){
        foreach($upFl as $atchFl){
        $path = 'mobile/chatbox/uploads/'.$atchFl['file_name'];
            @unlink($path);
         $dd = DB::query("DELETE FROM uploads WHERE message_id='".$_GET['msgid']."'");    
         } 
        }
        header("Location:dashboard.php?msgType=ci");
    }else{
        echo "Error!!";
    }
    
}

/*######## START HERE FOR THE SEND MAIL ########*/
if(isset($_POST['Send'])){
require 'Mail/PHPMailerAutoload.php';
$mail = new PHPMailer;
//$mail->SMTPDebug = 3;                               // Enable verbose debug output
$mail->isSMTP();                                      // Set mailer to use SMTP
$mail->Host = 'smtp.gmail.com';  // Specify main and backup SMTP servers
$mail->SMTPAuth = true;                               // Enable SMTP authentication
$mail->Username = 'bsi.marketintelligence@gmail.com';                 // SMTP username
$mail->Password = 'marketintelligence';                           // SMTP password
$mail->SMTPSecure = 'ssl';                            // Enable TLS encryption, `ssl` also accepted
$mail->Port = 465;                                    // TCP port to connect to
 
$mail->setFrom($_POST['ford_email'], 'BSI Group');
$mail->addAddress($_POST['forward'], $_POST['forward_name']); 
// $mail->addReplyTo('info@example.com', 'Information');
// $mail->addCC('cc@example.com');
// $mail->addBCC('bcc@example.com');

for($i = 0; $i<=count($_POST['ford_attach']); $i++){
$mail->AddAttachment("mobile/chatbox/uploads/".$_POST['ford_attach'][$i]);
}    
// Add attachments
// $mail->addAttachment('/tmp/image.jpg', 'new.jpg');    // Optional name
$mail->isHTML(true);                                  // Set email format to HTML

$mail->Subject = $_POST['ford_subject'];
$mail->Body    = $_POST['forward_Msg'];
//$mail->AltBody = 'This is the body in p lain text for non-HTML mail clients';

if(!$mail->send()) {
    $sendMail =  'Message could not be sent.';
    $sendMail =  'Mailer Error: ' . $mail->ErrorInfo;
} else {
    $sendMail = 'Message has been sent successfully!!';
    $upd = DB::query("UPDATE messages SET forwarded='1' WHERE id='".$_GET['msgid']."'");
}

}//end here isset
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>BSI Market Intelligence</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
     
 <!-- http://stackoverflow.com/questions/17627058/php-check-if-timestamp-is-greater-than-24-hours-from-now--> 
 <!-- http://stackoverflow.com/questions/12114329/calculating-days-hours-and-minutes-php-->
 <!-- http://stackoverflow.com/questions/1416697/converting-timestamp-to-time-ago-in-php-e-g-1-day-ago-2-days-ago --> 
    <link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Roboto+Slab" rel="stylesheet">
   
    <!-- Add jQuery library -->
	<script type="text/javascript" src="js/jquery-1.10.2.min.js"></script>
	<script type="text/javascript" src="js/jquery.fancybox.js"></script>
	<link rel="stylesheet" type="text/css" href="js/jquery.fancybox.css" media="screen">
    <script type="text/javascript">
		$(document).ready(function() {
			$('.fancybox').fancybox();
			$(".fancybox-effects-a").fancybox({
				helpers: {
					title : {
						type : 'outside'
					},
					overlay : {
						speedOut : 0
					}
				}
			});
		});
	</script>

    <style>
        body{font-family: 'Raleway', sans-serif; color: #626567;}        
.sidebar-nav {
    display: block;
    float: left;
    width: 250px;
    list-style: none;
    margin: 0;
    padding: 0;
}

        .sender{
            font-family: 'Roboto Slab', serif;
        }
        
#sidebar_menu li a, .sidebar-nav li a {
    color: #999;
    display: block;
    float: left;
    text-decoration: none;
    width: 250px;
    background: #fff;
    /*border-top: 1px solid #333;
    border-bottom: 1px solid #333;*/
    -webkit-transition: background .5s;
    -moz-transition: background .5s;
    -o-transition: background .5s;
    -ms-transition: background .5s;
    transition: background .5s;
}
.sidebar_name {
    padding-top: 25px;
    color: #fff;
    opacity: .7;
}

.sidebar-nav li {
  line-height: 40px;
  text-indent: 20px;
}

.sidebar-nav li .activ{background: #fff;border-left: 3px solid;border-left-color: #d72d18;color: #d72d18;}        
.sidebar-nav li a {
  color: black;
  display: block;
  text-decoration: none;
}

.sidebar-nav li a:hover {
  color:black;
  background:#f5f5f5;
  text-decoration: none;
  cursor: pointer;
  
}
.sidebar-nav li a:focus {
  text-decoration: none;
}
.sidebar-nav > .sidebar-brand {
  height: 65px;
  line-height: 60px;
  font-size: 18px;
}
.sidebar-nav > .sidebar-brand a {
  color: #666;
}
.sidebar-nav > .sidebar-brand a:hover {
  color: #fff;
  background: none;
}
       
.hed{ margin-top:15px;}
.text-white{color:#fff;text-align:right;}   
.txt{vertical-align:middle!important;}        
.md{margin-top:22px;}
 hr{margin-top:10px!important;margin-bottom:10px!important;}    
 b{color:black!important; font-weight:bold;}  
.btn1{ background-color:#F2F3F4!important; width:40px!important;height:30px!important;} 
.glyphicon{ color:#000!important;}   
        
.img{
    width: 120px;
    height: 120px;
    object-fit: cover;
    box-shadow: 2px 2px 3px grey;
}        
</style>
<script>
$(".fancybox").fancybox({
    beforeShow : function() {
        var alt = this.element.find('img').attr('alt');
        this.inner.find('img').attr('alt', alt);
        this.title = alt;
    }
});    
</script> 
    
<!--########## START HERE FOR THE FORWARD EMAIL ##########-->  
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css">
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script type="text/javascript">
$(document).ready(function(){ 
	$(".launch-modal").click(function(){
		$("#myModal").modal({
			backdrop: 'static'
		});
	}); 
});
</script>
<style type="text/css">
    .bs-example{
    	margin: 20px;
    }
</style>
<!--########## end HERE FOR THE FORWARD EMAIL ##########-->    
    
    
</head>
<body>
    <!-- Modal HTML -->
    <div id="myModal" class="modal fade">
        <div class="modal-dialog">
            <div class="modal-content">
                <form name="mailsend" method="post" action="">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                    <h4 class="modal-title">Forward Mail</h4>
                </div>
                <div class="modal-body">
                    <p>Please Enter your email address!!</p>
                    <input type="email" name="forward" class="form-control" placeholder="Enter your email id" required>
                    <input type="hidden" name="forward_Msg" value="<?=$msgData['message'];?>"/>
                    <input type="hidden" name="forward_name" value="<?=$userData['user_name'];?>"/>
                    <input type="hidden" name="ford_subject" value="<?=$msgData['subject']?>"/>
                    <input type="hidden" name="ford_email" value="<?=$userData['user_email'];?>"/>
                    <?php 
                     $allAttach = DB::query("SELECT * FROM uploads WHERE message_id=%d",$_GET['msgid']);
                             foreach ($allAttach as $allttRow){?>
                        <input type="hidden" name="ford_attach[]" value="<?=$allttRow['file_name'];?>"/>     
                    <?php } ?>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    <input type="submit" name="Send" class="btn btn-primary" value="Send">
                </div>
                </form>
            </div>
        </div>
    </div>
  <!--########## end HERE FOR THE FORWARD EMAIL ##########-->   
    
    
   <div class="container-fluid" style="background-color:#d72d18;">
    <div class="col-sm-2">
    <img src="images/logo.png" height="64">
    </div>    
    <div class="col-lg-6 hed">
     <form name="search" method="get" action="dashboard.php?"> 
        <input type="hidden" name="msgType" value="<?=$_GET['msgType'];?>">
    <div class="input-group">
      <input type="text" class="form-control" name="q" placeholder="Search for...">
      <span class="input-group-btn">
        <input type="submit" class="btn btn-default" name="Search" value="Go!">
      </span>
    </div><!-- /input-group -->
    </form> 
  </div><!-- /.col-lg-6 --> 
    <div class="col-sm-2 md">
    <div class="text-white"><?php echo $_SESSION["userName"];?></div>
    </div>
    <div class="col-sm-2 md">
    <div class="text-white">
        <?php if($_SESSION["userType"]=='777'){?> <a href="myaccount.php" style="cursor:pointer;"><img src="images/gear.png" height="28" width="28"></a><?php }?>
        <a href="logOut.php" style="cursor:pointer;"><img src="images/logout.png" height="28" width="28" style="margin-left:28px;"></a></div>
    </div>   
    </div>
    
    
<div class="container-fluid md">
    <!-- Sidebar -->
    <div class="col-sm-3">
      <div id="sidebar-wrapper">
        <ul class="sidebar-nav" id="sidebar">     
         <?php 
          if($_REQUEST['msgType']=="ci"){ $actvClas = "activ";}else{$actvClas = "";}
          if($_REQUEST['msgType']=="mi"){ $actvClas1 = "activ";}else{$actvClas1 = "";}
          if($_REQUEST['msgType']=="gi"){ $actvClas2 = "activ";}else{$actvClas2 = "";}
          if($_REQUEST['msgType']=="ti"){ $actvClas3 = "activ";}else{$actvClas3 = "";}
          if($_REQUEST['msgType']=="trends"){ $actvClas4 = "activ";}else{$actvClas4 = "";}    
         ?>    
          <li><a href="dashboard.php?msgType=ci" class="<?=$actvClas;?>">Competitor Information</a></li>
          <li><a href="dashboard.php?msgType=mi" class="<?=$actvClas1;?>">Market Intelligence</a></li>
          <li><a href="dashboard.php?msgType=gi" class="<?=$actvClas2;?>">Global Intelligence</a></li>
          <li><a href="dashboard.php?msgType=ti" class="<?=$actvClas3;?>">Traning Information</a></li>
          <li><a href="dashboard.php?msgType=trends" class="<?=$actvClas4;?>">Market Trends</a></li>
        </ul>
      </div>
    </div>
   
<div class="col-sm-9">    
  <div class="row sender">
      
      <?php if($sendMail!=""){?><div class="alert alert-success" style="padding:5px;margin-bottom: 10px; width:400px;">
        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
        <?=$sendMail;?></div><?php }?>
      
    <div class="col-sm-8">
      <b><?=ucwords($userData['user_name']);?> &lt;<?=$userData['user_email'];?>&gt;</b>
    </div>
    <div class="col-sm-4" style="text-align:right;">
      <b><?=$dd;?> (<?=timeAgo($msgData['datetime']);?>)</b>   &nbsp; &nbsp;
      <a href="message.php?del&msgid=<?=$_GET['msgid'];?>" class="btn btn1 btn-group-sm" onclick="return confirm('Are you sure you want to delete?');">
          <span class="glyphicon glyphicon-trash"></span></a>    
        &nbsp; &nbsp;
    <button type="button" class="btn btn1 btn-group-sm launch-modal"><span class="glyphicon glyphicon-share-alt"></span></button>   
    </div>
      
  </div>
    <div class="row">
        <div class="col-sm-12">
            <img style="width:18px;height:18px" src="images/location.png"/>
            <span><?=$msgData['address']?></span>
        </div>
    </div>
    <hr>
    <div class="row">
         <div class="col-sm-12">
        <p><?=$msgData['message']?></p>  
        </div>
    </div> 
    <hr/>
    <?php $resultData = DB::query("SELECT * FROM uploads WHERE message_id=%d",$_GET['msgid']); $attcountval = DB::count();?>
    <div class="col-12" style="margin-bottom:10px;color:d6d3d3!important"><b><?=$attcountval;?> Attachments</b></div>
    
    <div class="row">
        <!--############ START HERE FOR THE ATTACHEMENT ############-->
        <?php 
           
          foreach ($resultData as $attRow){ @extract($attRow);
          $attExp = explode(".",$file_name);
          //echo $attExp[1];
                                         
        if(($attExp[1]=="jpg")||($attExp[1]=="jpeg")||($attExp[1]=="png")||($attExp[1]=="gif")||($attExp[1]=="JPG")||($attExp[1]=="JPEG")||($attExp[1]=="PNG")){
            $FileAtta = '<a class="fancybox" href="mobile/chatbox/uploads/'.$file_name.'" data-fancybox-group="gallery" >
            <img src="mobile/chatbox/uploads/'.$file_name.'" height="120" width="120" class="img"></a>';  
        }else{
            $FileAtta = '<a href="mobile/chatbox/uploads/'.$file_name.'" download><img src="images/' . $attExp[1]  . '.png" class="img"></a>';
        }
        ?>
         <div class="col-sm-2"><?=$FileAtta;?></div>
         <?php } ?>
        <!--############ END HERE FOR THE ATTACHEMENT ############-->
    </div>
    </div>
</div>
    
		
	
</body>
</html>
