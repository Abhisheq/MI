<?php 

include 'connect.php';

$user_id = $_POST["user_id"];
$subject = $_POST["subject"];
$message = $_POST["message"];
$attach =  $_POST["attch"];
$msgType = $_POST["msg_type"];
$address = $_POST["address"];

DB::insert("messages", array(
    "user_id" => $user_id,
    "subject" => $subject,
    "message" => $message,
    "attachments" => $attach,
    "msg_type" => $msgType,
    "address" => $address
));

$messageId = DB::insertId();
$result;
if($messageId > 0){
    $result = array(
        "success" => true,
        "message_id" => $messageId
    );
}else{
    $result = array(
        "success" => false,
        "message_id" => -1
    );
}

echo json_encode($result);

?>