<?php 
include 'connect.php';

$email = $_POST['email'];
$password = $_POST['password'];

$userData = DB::queryFirstRow("SELECT * FROM users WHERE user_email=%s AND user_type=0 AND login_allowed=1", $email);


if(DB::count() == 0){

	$result = array(
        "success" => false,
        "message" => "Invalid user details"
    );
    
    echo json_encode($result);
    exit();
}

if(!password_verify($password,$userData['password'])){

	$result = array(
        "success" => false,
        "message" => "Invalid user details"
    );
    
    echo json_encode($result);
    exit();
	
}
	
$result = array(
    "success" => true,
    "message" => "",
    "userId" => $userData["id"]
);
    
echo json_encode($result);
exit();

?>